import os, random, string
from pathlib import Path
import environ
LOGIN_URL = 'login'
LOGOUT_URL = 'logout'
env = environ.Env()

LOGIN_REDIRECT_URL = 'home'
DB_ENGINE   = os.getenv('DB_ENGINE',None)
DB_USERNAME = env("DB_USER", None)
DB_PASS     = env("DB_PASSWORD", None)
DB_HOST     = env("DB_HOST", None)
DB_PORT     = env("DB_PORT", None)
DB_NAME     = env("DB_NAME", None)



if DB_ENGINE and DB_NAME and DB_USERNAME:
    DATABASES = {
      'default': {
        'ENGINE'  : 'django.db.backends.' + DB_ENGINE,
        'NAME'    : DB_NAME,
        'USER'    : DB_USERNAME,
        'PASSWORD': DB_PASS,
        'HOST'    : DB_HOST,
        'PORT'    : DB_PORT,
        },
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': 'db.sqlite3',
        }
    }
