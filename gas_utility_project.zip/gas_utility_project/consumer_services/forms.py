from django import forms
from .models import ServiceRequest

class ServiceRequestForm(forms.ModelForm):
    class Meta:
        model = ServiceRequest
        fields = ['service_type', 'details', 'attachment']

class RequestStatusForm(forms.Form):
    request_id = forms.IntegerField(label='Request ID')
