# consumer_services/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import ServiceRequest, CustomerAccount
from .forms import ServiceRequestForm, RequestStatusForm

@login_required
def submit_service_request(request):
    if request.method == 'POST':
        form = ServiceRequestForm(request.POST, request.FILES)
        if form.is_valid():
            service_request = form.save(commit=False)
            service_request.customer = request.user
            service_request.save()
            return redirect('request_submitted')
    else:
        form = ServiceRequestForm()
    return render(request, 'submit_service_request.html', {'form': form})

@login_required
def track_request_status(request):
    if request.method == 'POST':
        form = RequestStatusForm(request.POST)
        if form.is_valid():
            request_id = form.cleaned_data['request_id']
            try:
                request_status = ServiceRequest.objects.get(id=request_id)
                return render(request, 'request_status.html', {'request_status': request_status})
            except ServiceRequest.DoesNotExist:
                form.add_error('request_id', 'Invalid request ID')
    else:
        form = RequestStatusForm()
    return render(request, 'track_request_status.html', {'form': form})
